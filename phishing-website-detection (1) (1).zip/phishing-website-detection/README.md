# 🛡️ Phishing Website Detection

A web-based phishing website detection system built with **Python** and **Flask**. Users can enter any URL and the application instantly analyzes it for common phishing indicators, returning a clear **Legitimate** or **Phishing** verdict.

---

## 🚀 Features

- **Real-time URL Analysis** — Instantly checks any URL for phishing patterns
- **Score-based Detection** — Uses a multi-factor scoring system for accurate results
- **Clean Web Interface** — Modern, responsive UI with smooth animations
- **Explainable Logic** — Detection is based on well-known phishing heuristics

---

## 🛠️ Technologies Used

| Technology | Purpose                  |
|------------|--------------------------|
| Python     | Backend logic            |
| Flask      | Web framework & routing  |
| NumPy      | Feature array processing |
| HTML/CSS   | Frontend UI              |
| Jinja2     | Template rendering       |

---

## 📂 Project Structure

```
phishing-website-detection/
├── app.py                  # Flask application (routes & detection logic)
├── feature_extraction.py   # Extracts URL-based features
├── index.html              # Frontend template (HTML + CSS)
├── style.css               # Additional stylesheet
├── model.pkl               # Pre-trained model file
├── phishing.csv            # Dataset used for training/reference
├── phishing_detection.py   # Standalone detection script
├── requirements.txt        # Python dependencies
└── README.md               # Project documentation
```

---

## 🔍 How Detection Works

The application extracts **5 features** from the submitted URL and assigns a phishing score:

| # | Feature             | Condition                    | Score |
|---|---------------------|------------------------------|-------|
| 1 | **URL Length**       | Greater than 75 characters   | +1    |
| 2 | **@ Symbol**         | URL contains `@`             | +1    |
| 3 | **Dash (-) Symbol**  | URL contains `-`             | +1    |
| 4 | **HTTPS**            | URL does **not** use HTTPS   | +1    |
| 5 | **Subdomains**       | More than 3 dots in domain   | +1    |

> **Verdict:** If the total score is **≥ 3**, the URL is flagged as 🚨 **Phishing**. Otherwise, it is marked as ✅ **Legitimate**.

---

## ⚙️ Installation & Setup

### Prerequisites

- Python 3.7 or higher
- pip (Python package manager)

### Steps

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/phishing-website-detection.git
   cd phishing-website-detection
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the application**
   ```bash
   python app.py
   ```

4. **Open in browser**
   ```
   http://127.0.0.1:5000
   ```

---

## 🧪 Test URLs

Use these safe, fabricated URLs to test the detection system:

### 🚨 Phishing (Score ≥ 3)

```
http://example-test.com/login@user
```
> Triggers: no HTTPS (+1), dash (+1), @ symbol (+1) → **Score = 3**

```
http://sub1.sub2.sub3.sub4.example-test.com/login-verification@user-account-update-with-a-very-long-url-exceeding-75-chars
```
> Triggers: all 5 rules → **Score = 5**

### ✅ Legitimate (Score < 3)

```
https://www.google.com
```
> Triggers: none → **Score = 0**

```
https://example.com/login
```
> Triggers: none → **Score = 0**

---

## 📸 Screenshot

Once running, the application displays a clean interface where users can paste a URL and click **Analyze URL** to receive an instant phishing verdict.

---

## 🤝 Contributing

Contributions are welcome! Feel free to open an issue or submit a pull request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/new-feature`)
3. Commit your changes (`git commit -m "Add new feature"`)
4. Push to the branch (`git push origin feature/new-feature`)
5. Open a Pull Request

---

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

---

## 👤 Author

Made with ❤️ for cybersecurity awareness.
